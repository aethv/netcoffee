package com.clinet.application;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.clinet.model.AccountDTO;
import com.interf.test.CommonRemote;
import com.interf.test.Messenger;
import com.interf.test.SimpleMessenger;

public class UILogin extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(UILogin.class);
	
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	private String username;
	private CommonRemote cr;

	public UILogin() {
		super();
		initComponents();
	}

	public static void main(String[] args) {
		UILogin ui = new UILogin();
		ui.setVisible(true);
		
		//TODO initialize new SwingWorker to hook and initialize Server + update server status
	}
	
	protected void login() {
		try{
			username = txtUsername.getText();
			Messenger messenger = new SimpleMessenger(
				new AccountDTO(username, txtPassword.getPassword().toString())
			);
			
			//TODO invoke new SwingWorker to login and repeat if failed
			if(!cr.login(messenger)){
				throw new Exception("Unable to login");
			}
		}catch(Exception ex){
			LOGGER.error("Exception when login", ex);
		}
	}

	protected void close() {
		try{
			System.out.println("Doing something on closing");
			cr.logout(username);
		}catch(Exception ex){
			LOGGER.error("Exception when closing UILogin", ex);
		}
	}

	private void initComponents() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				System.out.println("Window Activated");
			}
			@Override
			public void windowOpened(WindowEvent e) {
				System.out.println("Window Opened");
			}
			@Override
			public void windowClosing(WindowEvent e) {
				close();
			}
		});
		setType(Type.UTILITY);
		setResizable(false);
		setTitle("Login - FoodNet");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(UIManager.getColor("Panel.background"));
		getContentPane().add(panel_2, BorderLayout.SOUTH);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login();
			}
		});
		btnLogin.setMnemonic('L');
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				close();
			}
		});
		btnClose.setMnemonic('C');
		panel_2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		panel_2.add(btnLogin);
		panel_2.add(btnClose);
		
		JPanel panel_3 = new JPanel();
		getContentPane().add(panel_3, BorderLayout.CENTER);
		
		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtUsername.setText("admin");
		txtUsername.setColumns(10);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setLabelFor(txtUsername);
		lblUsername.setDisplayedMnemonic('U');
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setDisplayedMnemonic('p');
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtPassword = new JPasswordField();
		lblPassword.setLabelFor(txtPassword);
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel = new JLabel("Connecting to server");
		lblNewLabel.setIcon(new ImageIcon(UILogin.class.getResource("/icons/loading-15x15.gif")));
		GroupLayout gl_panel_3 = new GroupLayout(panel_3);
		gl_panel_3.setHorizontalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_3.createSequentialGroup()
							.addComponent(lblUsername)
							.addGap(8)
							.addComponent(txtUsername, GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE))
						.addGroup(gl_panel_3.createSequentialGroup()
							.addComponent(lblPassword)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel)
								.addComponent(txtPassword, GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE))))
					.addContainerGap())
		);
		gl_panel_3.setVerticalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addGap(5)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtUsername, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblUsername))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword)
						.addComponent(txtPassword, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
					.addComponent(lblNewLabel)
					.addContainerGap())
		);
		panel_3.setLayout(gl_panel_3);
		pack();
	}
	
}
