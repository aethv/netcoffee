To build project, execute command: "mvn clean install" on these project respectively: 
1. ExampleCommon
2. ExampleClient
3. ExampleServer