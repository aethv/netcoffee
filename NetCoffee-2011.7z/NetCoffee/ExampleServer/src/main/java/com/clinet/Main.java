package com.clinet;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.clinet.application.UIMain;

public class Main {

	private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);
	
	public static void main(String[] args) {
		try {
			LOGGER.debug("begin setting L&F");
		    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
		        if ("Nimbus".equals(info.getName())) {
		            UIManager.setLookAndFeel(info.getClassName());
		            break;
		        }
		    }
		    LOGGER.debug("L&F is set to: " + UIManager.getLookAndFeel().getName());
		} catch (Exception e) {
			LOGGER.debug("L&F is unable to set");
		}
		/* Turn off metal's use of bold fonts */
        UIManager.put("swing.boldMetal", Boolean.FALSE);
		
		//start application
		//TODO: start 2 app: chat and main respectively
		Main.LOGGER.debug("staring main application");
		SwingUtilities.invokeLater(new Runnable() {
			
			public void run() {
				UIMain mainApp = new UIMain();
				mainApp.setSize(800, 600);
				mainApp.setLocationRelativeTo(null);
				mainApp.setDefaultCloseOperation(UIMain.EXIT_ON_CLOSE);
				mainApp.setVisible(true);
				
				mainApp.addWindowListener(new WindowAdapter() {
					@Override
					public void windowClosing(WindowEvent e) {
						Main.LOGGER.debug("main app closing");
					}
				});
			}
		});
	}
}
