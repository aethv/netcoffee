package com.clinet.external;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.clinet.dao.AccountDAO;
import com.clinet.model.Account;
import com.interf.test.CommonRemote;
import com.interf.test.Messenger;

public class ServerProcess extends UnicastRemoteObject implements CommonRemote {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = LoggerFactory.getLogger(ServerProcess.class);
	private AccountDAO accDAO = new AccountDAO();
	private Map<String, Messenger> mapUser = new HashMap<String, Messenger>();
	
	public ServerProcess() throws RemoteException {
		super();
	}

	public boolean login(Messenger messInterface) throws RemoteException {
		LOGGER.debug("loging to system by user: " + messInterface.getAccount());
		try {
			Account acc = accDAO.validateLogin(messInterface.getAccount());
			LOGGER.debug("get acc from db: " + acc);
			
			if(acc == null){
				return false;
			}
			
			if(!acc.isActive()){
				return false;
			}
			LOGGER.info("logined successfully by user: " + acc.getUsername());
			
			acc.setLastLogined(Calendar.getInstance().getTimeInMillis());
			accDAO.update(acc);
			mapUser.put(acc.getUsername(), messInterface);
		}catch(Exception ex) {
			LOGGER.error("Unable to login", ex);
		}finally {
			LOGGER.debug("done processing login");
		}
		return true;
	}

	public void logout(String username) throws RemoteException {
		LOGGER.debug("trying to logout user: " + username);
		if(! mapUser.containsKey(username)) {
			LOGGER.error("Big problem here!!!!. Logout by unfound user: " + username);
		} else {
			mapUser.remove(username);
			LOGGER.info("logout successfully by user: " + username);
		}
	} 

	public void sendMessage(Messenger messgerInterface, String msg)
			throws RemoteException {
		// TODO Auto-generated method stub
		
	}
	
	
}
